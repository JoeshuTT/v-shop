# v-shop

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Rem 适配
```
// postcss 插件，用于将单位转化为 rem
npm install postcss-pxtorem --save-dev
// 用于设置 rem 基准值
npm install amfe-flexible --save
```

### 数据来源
```
https://m.mi.com/
```
### 阿里云短信
AccessKeyId	AccessKeySecret
LTAIcItFW6Ilh5KW	iCOp9El80dsr6MUM8ClLwhNyLWK6UY

### 用户本地信息
```
window.localStorage.setItem('token',JSON.stringify('50274412-f43b-4a35-a09e-a935e25556d2'))
window.localStorage.setItem('uid',JSON.stringify('uid'))
```
### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
