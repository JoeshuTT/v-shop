<template>
  <div class="contaienr">
      aaa
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  },
  created() {},
  methods: {}
}
</script>

<style lang="less" scoped>

</style>


