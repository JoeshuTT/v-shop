import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const routes = [
  {
    path: '',
    redirect: '/home'
  },
  {
    name: 'home',
    component: () => import('./pages/home/home'),
    meta: {
      title: '首页'
    }
  },
  {
    name: 'user',
    component: () => import('./pages/user/user'),
    meta: {
      title: '会员中心'
    }
  },
  {
    name: 'cart',
    component: () => import('./pages/cart/cart'),
    meta: {
      title: '购物车'
    }
  },
  {
    name: 'login',
    component: () => import('./pages/login/login'),
    meta: {
      title: '登录'
    }
  },
  {
    name: 'goods-detail',
    component: () => import('./pages/goods-detail/goods-detail'),
    meta: {
      title: '商品详情'
    }
  },
  {
    name: 'order-submit',
    component: () => import('./pages/order-submit/order-submit'),
    meta: {
      title: '待付款的订单'
    }
  },
  {
    name: 'address-list',
    component: () => import('./pages/address-list/address-list'),
    meta: {
      title: '地址列表'
    }
  },
  {
    name: 'address-edit',
    component: () => import('./pages/address-edit/address-edit'),
    meta: {
      title: '地址编辑'
    }
  },
]

// add route path
routes.forEach(route => {
  route.path = route.path || '/' + (route.name || '');
})

const router = new Router({routes})

// add route title
router.beforeEach((to, from, next) => {
  const title = to.meta && to.meta.title;
  if (title) {
    document.title = title;
  }
  next();
});

export default router
