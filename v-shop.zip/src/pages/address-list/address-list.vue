<template>
  <div class="contaienr">
    <van-address-list
      v-model="chosenAddressId"
      :list="list"
      @add="onAdd"
      @edit="onEdit"
      @select="onSelect"
    />
  </div>
</template>

<script>
import { AddressList } from 'vant'
import { storage } from '@/common/util'
import { mapState,mapMutations} from 'vuex'
let flag;
export default {
  components: {
    [AddressList.name]: AddressList,
  },
  data() {
    return {
      chosenAddressId: '',
      list: [],
    }
  },
  created() {
    console.log(this.$router)
    flag=false
    this.$request.get('/user/shipping-address/list',{token:storage.get('token')}).then(res=>{
      this.list = res.data.map(item => ({
          id: item.id,
          name: item.linkMan,
          tel: item.mobile,
          address: item.provinceStr + item.address,
          cityId:item.cityId,  // 城市编码
          code:item.code,
          provinceId:item.provinceId,
      }))
    })
  },
  methods: {
    ...mapMutations(['updateDefaultAddress']),
    onAdd() { 
      this.$router.push({path:'address-edit'})
    },
    onEdit(item, index) {
      this.$router.push({path:'address-edit',query:{id:item.id}})
    },
    onSelect(item, index) {
      // ?会触发2次方法
      if(!flag){
        flag=true
        this.$router.back(-1)
        // this.$bus.$emit('defaultAddress',item)
        this.updateDefaultAddress(item)
      }
    }
  }
}
</script>

<style lang="less" scoped>

</style>


