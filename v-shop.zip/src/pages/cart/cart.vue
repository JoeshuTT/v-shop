<template>
    <div class="container">
      <div class="goods-box" v-if="goods.length">
      <van-cell value="商城" icon="shop-o" />
 <van-checkbox-group class="list" v-model="checkedGoods">
      <van-checkbox
        class="list-item"
        v-for="item in goods"
        :key="item.id"
        :name="item.id"
        checked-color="#ff4444"
      >
        <van-card
          :title="item.title"
          :desc="item.desc" 
          :price="formatPrice(item.price)"
          :thumb="item.thumb"
        >
        <div slot="num">
    <van-stepper v-model="item.num" />
  </div>
        </van-card>
        
      </van-checkbox>
    </van-checkbox-group>
<!-- 结算 -->
        <van-submit-bar
    class="submit-bar"
  :price="totalPrice"
  :button-text="submitBarText"
  :disabled="!checkedGoods.length"
  @submit="onSubmit"
>
  <van-checkbox v-model="checkedAll">全选</van-checkbox>
</van-submit-bar>
      </div>
     
    <div class="no-data" v-else>
        <img src="../../assets/no-cart.png" alt="">
        <div class="no-data-title">购物车快饿瘪了 T.T</div>
        <div class="no-data-txt">快给我挑点宝贝</div>
        <van-button class="no-data-btn" plain type="danger" @click="handleHomePage">去逛逛</van-button>
      </div>
        
        <!-- 底部导航栏 -->
        <van-tabbar route v-model="active">
  <van-tabbar-item
    replace
    to="/home"
    icon="home-o"
  >
    首页
  </van-tabbar-item>
  <van-tabbar-item
    replace
    to="/cart"
    icon="cart-o"
  >
    购物车
  </van-tabbar-item>
  <van-tabbar-item
    replace
    to="/user"
    icon="manager-o"
  >
    我的
  </van-tabbar-item>
</van-tabbar>
    </div>
</template>
<script>
import { Tabbar, TabbarItem,Checkbox, CheckboxGroup, Card,Stepper,SubmitBar } from "vant";
export default {
  components: {
    [Tabbar.name]: Tabbar,
    [TabbarItem.name]: TabbarItem,
    [Checkbox.name]: Checkbox,
    [CheckboxGroup.name]: CheckboxGroup,
    [Card.name]: Card,
    [Stepper.name]: Stepper,
    [SubmitBar.name]: SubmitBar,
    // [SwipeItem.name]: SwipeItem,
  },
  data() {
    return {
      active: 0,
      iamges: [],
      checkedAll:false,
      checkedGoods: ['1', '2', '3'],
      goods: [{
        id: '1',
        title: '进口香蕉',
        desc: '约250g，2根',
        price: 200,
        num: 1,
        thumb: 'https://img.yzcdn.cn/public_files/2017/10/24/2f9a36046449dafb8608e99990b3c205.jpeg'
      }, {
        id: '2',
        title: '陕西蜜梨',
        desc: '约600g',
        price: 690,
        num: 1,
        thumb: 'https://img.yzcdn.cn/public_files/2017/10/24/f6aabd6ac5521195e01e8e89ee9fc63f.jpeg'
      }, {
        id: '3',
        title: '美国伽力果',
        desc: '约680g/3个',
        price: 2680,
        num: 1,
        thumb: 'https://img.yzcdn.cn/public_files/2017/10/24/320454216bbe9e25c7651e1fa51b31fd.jpeg'
      }]
    }
  },
  computed: {
    submitBarText() {
      const count = this.checkedGoods.length
      return '结算' + (count ? `(${count})` : '')
    },
    totalPrice() {
      return this.goods.reduce((total, item) => total + (this.checkedGoods.indexOf(item.id) !== -1 ? item.price : 0), 0)
    }
  },
  mounted() {

  },
  methods: {
    formatPrice(price) {
      return (price / 100).toFixed(2);
    },
    handleHomePage(){
      this.$router.replace({path:'/home'})
    },
    onSubmit(){
      // this.$toast('点击结算')
      this.$router.push({path:'/order-submit'})
    }
  }
};
</script>
<style lang="less" scoped>
  .list{
    padding: 10px 0;
    background-color: #fff;
    &-item{
      position: relative;
      .van-card {
        background-color: #fff;
      }
      /deep/ .van-checkbox__label {
        width: 100%;
        height: auto; // temp
        padding: 0 10px 0 15px;
        box-sizing: border-box;
      }
      /deep/ .van-checkbox__icon {
        top: 50%;
        left: 10px;
        z-index: 1;
        position: absolute;
        margin-top: -10px;
        font-size: 16px;
      }
      .van-card__price {
        color: #f44;
      }
      .van-card__bottom{
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
      }
    }
  }
  .submit-bar{
    .van-checkbox{
      margin-left:40px;
    }
  }
  .no-data{
    padding-top:150px;
    text-align: center;
    >img{
      display: inline-block;
      width: 290px;
      margin-bottom: 20px;
    }
    &-title{
      font-size: 16px;
      color: #666;
      font-weight: 400;
      margin-bottom: 10px;
    }
    &-txt{
      font-size: 14px;
      color: #999;
      margin-bottom: 10px;
    }
    &-btn{
      // padding: 0 30px;
    }
  }
</style>



