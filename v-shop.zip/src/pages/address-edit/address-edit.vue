<template>
  <div class="contaienr">
    <van-address-edit
      :address-info="addressInfo"
      :area-list="areaList"
      show-postal
      :show-delete="status==1"
      show-set-default
      @save="onSave"
      @delete="onDelete"
    />
  </div>
</template>

<script>
import { AddressEdit } from 'vant'
import areaList from '@/common/area'
import { storage } from '@/common/util'
import { isEmpty } from '@/common/validate'

export default {
  components:{
    [AddressEdit.name]:AddressEdit,
  },
  data() {
    return {
      status:0,  // 0添加地址,1修改地址
      addressInfo:{},
      areaList,
      searchResult: []
    }
  },
  created() {
    if(this.$route.query.id){
      this.status = 1
      this.$request.get('/user/shipping-address/detail',{id:this.$route.query.id,token:storage.get('token')}).then(res=>{
        this.addressInfo={
          addressDetail:res.data.address,
          areaCode:res.data.cityId,  // 城市编码
          postalCode:res.data.code,
          name:res.data.linkMan,
          tel:res.data.mobile,
          areaCode:res.data.provinceId,  // 省份编码
          isDefault:res.data.isDefault,
        }
      })
    }
  },
  methods: {
    onSave(form) {
      if(!isEmpty(form.postalCode)){
        this.$toast('请填写邮政编码')
        return;
      }
      const params = {
        token:storage.get('token'),
        address:form.addressDetail,
        cityId:form.areaCode,  // 城市编码
        code:form.postalCode,
        linkMan:form.name,
        mobile:form.tel,
        provinceId:form.areaCode.slice(0,2)+'0000',  // 省份编码
        isDefault:form.isDefault,
      }
      this.status === 1 ? this.updateAddress(params) : this.addAddress(params)
    },
    updateAddress(params){
      this.$toast.loading({
        mask: true,
        message: '地址数据提交中...'
      })
      this.$request.post('/user/shipping-address/update',{id:this.$route.query.id,...params}).then(res=>{
        if(res.code === 0){
          this.$toast.clear()
          this.$router.go(-1)
        }else{
          this.$toast(res.msg)
        }
      })
    },
    addAddress(params){
      this.$toast.loading({
        mask: true,
        message: '地址数据提交中...'
      })
      this.$request.post('/user/shipping-address/add',params).then(res=>{
        if(res.code === 0){
          this.$toast.clear()
          this.$router.go(-1)
        }else{
          this.$toast(res.msg)
        }
      })
    },
    onDelete() {
      this.$toast('delete');
    },
  }
}
</script>

<style lang="less" scoped>

</style>


