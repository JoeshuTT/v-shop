<template>
    <div class="contaienr pd50">
        <van-swipe :autoplay="3000" indicator-color="white" class="goods-swiper">
            <van-swipe-item v-for="item in banner" :key="item.id">
                <img :src="item.pic" alt="" />
            </van-swipe-item>
        </van-swipe>
        <div class="goods-desc mb10">
          <div class="goods-desc-name">{{basicInfo.name}}--分享有礼按钮</div>
          <div class="goods-desc-brief" v-if="basicInfo.characteristic">{{basicInfo.characteristic}}</div>
          <div class="goods-desc-price">￥{{basicInfo.minPrice}}<!-- <span class="goods-desc-price-span">￥{{basicInfo.originalPrice}}</span> --></div>
          <div class="goods-desc-more">
            <div class="goods-desc-more-item">浏览：{{basicInfo.views}}</div>
            <div class="goods-desc-more-item ui-center">购买：{{basicInfo.numberOrders}}</div>
            <div class="goods-desc-more-item ui-right">好评：{{basicInfo.numberGoodReputation}}</div>
          </div>
        </div>
        <div class="goods-section">
          <van-cell class="mb10" title="领券" is-link @click="onShowCoupon" />
          <van-cell class="mb10" title="选择 规格字段名字" is-link @click="onShowSku" />
          <van-cell class="mb10" title="服务 担保交易" is-link @click="onShowService" />
        </div>
        <div class="goods-reputation mb10" @click="onShowReputation">
           <van-cell class="mb10" title="评价(46)" value="全部评价" is-link  />
           <van-cell class="mb10" title="暂无评价" />
           <div class="goods-reputation-inner">
             <div class="goods-reputation-inner-hd">
               <div class="goods-reputation-inner-media"><img src="../../assets/avatar_default.png" alt=""></div>
               <div class="goods-reputation-inner-name">1**8</div>
               <div class="goods-reputation-inner-stars">五颗星</div>
             </div>
             <div class="goods-reputation-inner-bd">
               <span class="goods-reputation-inner-tag">质量不错</span>
               <span class="goods-reputation-inner-tag">下次再来</span>
             </div>
             <div class="goods-reputation-inner-ft">茶不错,味道尚可,并耐泡!</div>
           </div>
        </div>
        <div class="goods-h2 common-h2"><span class="common-h2-title">商品详情</span></div>
        <div class="goods-content" v-html="content"></div>




<!-- 领券弹层 -->
<van-popup v-model="showService" position="bottom">
  <div class="popup">
    <div class="service-desc">霹雳拍啦</div>
    <van-button class="popup-confirm" type="danger" size="large" @click="onShowService">我知道了</van-button>
  </div>
</van-popup>
<!-- 服务弹层 -->
<van-popup v-model="showCoupon" position="bottom">
  <div class="popup popup-coupon">
    <div class="coupon-list-header van-hairline--bottom" v-if="coupons.length">可用优惠券</div>
    <div class="coupon-list" v-if="coupons.length">
      <div class="coupon-list-item" v-for="coupon in coupons" :key="coupon.id">
        <div class="coupon-list-item-hd">
          <div class="coupon-list-item-money"><span class="fz12">￥</span>{{coupon.moneyMin}}</div>
          <div class="coupon-list-item-moneyHreshold">满{{coupon.moneyHreshold}}可用</div>
        </div>
        <div class="coupon-list-item-bd">
          <div class="coupon-list-item-name">{{coupon.moneyMin}}元券</div>
          <div class="coupon-list-item-dateEndDays">领取后{{coupon.dateEndDays}}天有效</div>
        </div>
        <!-- :class="[couponStatus==='立即领取' ? '' : 'coupon-list-item-btn-clicked']" -->
        <div class="coupon-list-item-btn" :class="[couponStatus==='领取成功' ? 'coupon-list-item-btn-clicked' : '']" @click="handleCouponClicked(coupon.id)">{{couponStatus}}</div>
      </div> 
    </div>
    <div class="no-data" v-else>暂无可用优惠券</div>
    <van-icon name="close" class="popup-close" @click="onShowCoupon" />
    <van-button class="popup-confirm" type="danger" size="large" @click="onShowCoupon">完成</van-button>
  </div>
</van-popup>
<!-- 商品规格弹层 -->
<div class="sku-container">
  <van-sku
  hide-quota-text
  v-model="showSku"
  :sku="skuData.sku"
  :goods="skuData.goods_info"
  :goods-id="skuData.goods_id"
  :hide-stock="skuData.hide_stock"
  :quota="skuData.quota"
  :quota-used="skuData.quota_used"
  :custom-stepper-config="stepperConfig"
  :message-config="messageConfig"
  :show-soldout-sku="false"
  @buy-clicked="onBuyClicked"
  @add-cart="onAddCartClicked"
/>
</div>
<!-- 商品导航 -->
<van-goods-action>
  <van-goods-action-icon
    icon="thumb-circle-o"
    text="首页"
    to="/home"
  />
  <van-goods-action-icon
    icon="chat-o"
    text="客服"
    @click="onClickIcon"
  />
  <van-goods-action-icon
    icon="cart-o"
    text="购物车"
    @click="onClickIcon"
    to="/cart"
  />
  <van-goods-action-button
    type="warning"
    text="加入购物车"
    @click="onClickButton"
  />
  <van-goods-action-button
    type="danger"
    text="立即购买"
    @click="onClickButton"
  />
</van-goods-action>
    </div>
</template>
<script>
import { Swipe, SwipeItem ,Sku,  GoodsAction, GoodsActionIcon, GoodsActionButton} from 'vant'
// import { isString,isArray } from '@/common/validate'
import { storage } from '@/common/util'
export default {
  components: {
    [Swipe.name]: Swipe,
    [SwipeItem.name]: SwipeItem,
    [Sku.name]: Sku,
    [GoodsAction.name]: GoodsAction,
    [GoodsActionIcon.name]: GoodsActionIcon,
    [GoodsActionButton.name]: GoodsActionButton,
  },
  data() {
    return {
      banner:[],
      basicInfo:{},
      content:'',
      properties:[],
      showCoupon:false,
      coupons:[],
      couponStatus:'立即领取',
      showService:false,
      showSku:false,
      skuData:{},
      stepperConfig:{},
      messageConfig:{},
    }
  },
  watch: {
    //   $route
  },
  created() {
    console.log(this.$route.query);
    this.getGoodsDetail(this.$route.query.id)
    this.skuData = {
       kdt_id: 55,
  user_id: 4674509,
  offline_id: 0,
  activity_alias: '',
  sku: {
    tree: [
      {
        k: '颜色',
        k_id: '1',
        v: [
          {
            id: '30349',
            name: '天蓝色',
            imgUrl:
              'https://img.yzcdn.cn/upload_files/2017/02/21/FjKTOxjVgnUuPmHJRdunvYky9OHP.jpg!100x100.jpg'
          },
          {
            id: '1215',
            name: '白色'
          }
        ],
        k_s: 's1',
        count: 2
      },
      {
        k: '尺寸',
        k_id: '2',
        v: [
          {
            id: '1193',
            name: '1'
          },
          {
            id: '1194',
            name: '2'
          }
        ],
        k_s: 's2',
        count: 2
      }
    ],
    list: [
      {
        id: 2259,
        price: 100,
        discount: 100,
        code: '',
        s1: '1215',
        s2: '1193',
        s3: '0',
        s4: '0',
        s5: '0',
        extend: null,
        kdt_id: 55,
        discount_price: 0,
        stock_num: 110,
        stock_mode: 0,
        is_sell: null,
        combin_sku: false,
        goods_id: 946755
      },
      {
        id: 2260,
        price: 100,
        discount: 100,
        code: '',
        s1: '1215',
        s2: '1194',
        s3: '0',
        s4: '0',
        s5: '0',
        extend: null,
        kdt_id: 55,
        discount_price: 0,
        stock_num: 0,
        stock_mode: 0,
        is_sell: null,
        combin_sku: false,
        goods_id: 946755
      },
      {
        id: 2257,
        price: 100,
        discount: 100,
        code: '',
        s1: '30349',
        s2: '1193',
        s3: '0',
        s4: '0',
        s5: '0',
        extend: null,
        kdt_id: 55,
        discount_price: 0,
        stock_num: 111,
        stock_mode: 0,
        is_sell: null,
        combin_sku: false,
        goods_id: 946755
      },
      {
        id: 2258,
        price: 100,
        discount: 100,
        code: '',
        s1: '30349',
        s2: '1194',
        s3: '0',
        s4: '0',
        s5: '0',
        extend: null,
        kdt_id: 55,
        discount_price: 0,
        stock_num: 6,
        stock_mode: 0,
        is_sell: null,
        combin_sku: false,
        goods_id: 946755
      }
    ],
    price: '1.00',
    stock_num: 227,
    collection_id: 2261,
    collection_price: 0,
    none_sku: false,
    // messages: [
    //   {
    //     type: 'text',
    //     name: '留言',
    //     placeholder:'点击填写留言',
    //     required: 0
    //   },
    // ],
    hide_stock: false
  },
  goods_id: '946755',
  alias: '2oml0r0n5vytj',
  quota: 15,
  is_virtual: '0',
  quota_used: 0,
  goods_info: {
    title: '测试商品',
    picture:
      'https://img.yzcdn.cn/upload_files/2017/03/16/Fs_OMbSFPa183sBwvG_94llUYiLa.jpeg?imageView2/2/w/100/h/100/q/75/format/jpg',
    price: '555',
    origin: ''
  }
    }
  },
  methods: {
    onClickIcon() {
      this.$toast('点击图标');
    },
    onClickButton() {
      this.$toast('点击按钮');
      this.$router.push({path:'/order-submit'})
    },
    onShowService(){
      this.showService = !this.showService
    },
    onShowCoupon(){
      this.showCoupon = !this.showCoupon
      if(!this.coupons.length){
        this.$request.get('/discounts/coupons', {}).then(res => {
          this.coupons = res.data || []
          // 
          //
        })
      }
    },
    handleCouponClicked(id){
      this.$request.post('/discounts/fetch', {id,token:storage.get('token')}).then(res => {
          if(res.code === 0){
            // this.$toast('领取成功') 
            this.$toast({message:'恭喜,抢到了~',duration:1500})
            this.couponStatus = '继续领取'
          }else if(res.code === 20001||res.code === 20002 || res.code === 20003){
            // this.$toast(res.msg)
            this.$toast({message:'很遗憾,没抢到~',duration:1500})
            this.couponStatus = '领取成功'
          } else {
            this.$toast(res.msg)
          }
        })
    },
    onShowReputation(){
      this.$toast('查看全部评价');
      // this.$router.push({path:'/goods-reputation'})
    },
    onShowSku(){
      this.showSku = !this.showSku
    },
    onBuyClicked(data) {
      this.$toast('buy:' + JSON.stringify(data));
    },
    onAddCartClicked(data) {
      this.$toast('add cart:' + JSON.stringify(data));
    },
    getGoodsDetail(id) {
      this.$request.post("/shop/goods/detail", { id }).then(res => {
        // this.goodsDetail = res.data
        this.banner = res.data.pics
        this.basicInfo = res.data.basicInfo
        this.content = res.data.content
        this.properties = res.data.properties
        // 商品规格sku数据
        
      })
    }
  }
}
</script>
<style lang="less" scoped>
.text-left{
  text-align: left;
}
.goods-swiper {
  width: 100%;
  height: 410px;
}
.goods-desc{
  box-sizing: border-box;
  padding: 0 15px;
  background: #fff;
  &-name{
    font-size: 20px;
    font-weight: bold;
    color: #333;
    padding: 10px 0;
  }
  &-brief{
    font-size: 12px;
    color: #888;
    margin-bottom: 10px;
  }
  &-price{
    font-size: 24px;
    color: #E60012;
    &-span{
      margin-left: 5px;
      font-size:12px;
      text-decoration: line-through;
      color:#999;
    }
  }
  &-more{
    box-sizing: border-box;
    width: 100%;
    display: flex;
    justify-content: space-around;
    align-items: center;
    height: 30px;
    &-item{
      flex:1;
      font-size: 12px;
      color: #999;
    }
  }
}

.goods-content /deep/ img{
  max-width:100%!important;
  height:auto!important;
}
.goods-content{
  box-sizing: border-box;
  background: #fff;
}

.goods-reputation{
  background: #fff;
  &-inner{
    padding:0 15px;
    &-hd{
      display: flex;
      justify-content: flex-start;
      align-items: center;
      margin-bottom:10px;
      font-size: 12px;
      color:#666;
    }
    &-media{
      width:30px;
      height:30px;
      border-radius: 50%;
      overflow: hidden;
      background: #eee;
      margin-right: 5px;
    }
    &-name{
      flex:1;
    }
    &-stars{
    
    }
    &-tag{
      padding: 2px 10px;
      border-radius: 10px;
      border: 1px solid #979797;
      font-size: 10px;
      color:#999;
      margin-right: 10px;
    }
    &-bd{
      padding:10px 0;
    }
    &-ft{
      padding:5px 0 10px;
      font-size: 14px;
      color:#333;
    }
  }
}
.service-desc{
  height: 70vh;
  padding: 10px 15px;
  font-size: 14px;
  color:#666;
}
.popup-coupon{
  position: relative;
  padding-top: 44px;
  padding-bottom: 50px;
}
.coupon-list{
  padding:10px 15px;
  max-height: 70vh;
  overflow-y: auto;
  &-header{
    position: absolute;
    box-sizing: border-box;
    width:100%;
    top:0;
    left:0;
    font-size: 14px;
    color:#333;
    padding: 10px 0;
    text-align: center;
  }
}
.coupon-list-item{
  box-sizing: border-box;
  height:76px;
  position: relative;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  background: #ffeeee;
  color: #ff4b52;
  margin-bottom:10px;
  border-radius: 4px;
  &-hd{
    width: 100px;
    text-align: center;
    border-right: 1px slategrey #eee;
  }
  &-money{
    font-size: 24px; 
    font-weight: bold;
    // margin-bottom:10px;
  }
  &-moneyHreshold{
    font-size: 12px;
  }
  &-bd{
    flex:1;
  }
  &-name{
    font-size: 14px;
    padding: 5px 0;
  }
  &-dateEndDays{
    font-size: 12px;
    color:#d7a0a5;
  }
  &-btn{
    margin-right: 10px;
    display: inline-block;
    padding: 0.2em 0.5em;
    color: #fff;
    background: #ff4444;
    font-size: 10px;
    line-height: normal;
    border-radius: 0.8em;
  }
  &-btn-clicked{
    color: #ff4444;
    background: #ffffff;
    border: 1px solid #ff4444;
    pointer-events: none;
  }
}

/* 弹层*/
.popup{
  position: relative;
  padding-bottom: 50px;
  &-confirm{
    position: absolute;
    left: 0;
    bottom:0;
  }
  &-close{ 
    position: absolute;
    top: 10px;
    right: 15px;
    color: #969799;
    font-size: 20px;
    text-align: center;
  }
}
</style>


