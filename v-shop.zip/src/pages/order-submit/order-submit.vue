<template>
  <div class="contaienr">
    <div class="address-box mb10" v-if="defaultAddress.name" @click="onAddressChoose">
      <div class="address-box-hd">
        <div class="address-box-inner">
          <van-icon name="location-o" class="address-box-inner-icon"/>
          <div class="address-box-inner-title">收货人：{{defaultAddress.name}}</div>
          <div class="address-box-inner-title">{{defaultAddress.tel}}</div>
        </div>  
        <div class="address-box-inner-bottom">收货地址：{{defaultAddress.address}}</div>
      </div>
      <div class="address-box-bd"><van-icon name="arrow" /></div>
    </div> 
    <van-cell v-else class="address-card mb10" title="新增收货地址" icon="add-square" is-link @click="onAddressChoose"></van-cell>

    <div class="order-info">
        <van-cell-group>
  <van-cell title="商品列表"></van-cell>

      <van-card
  num="2"
  price="2.00"
  desc="描述信息"  
  title="商品标题"
  :thumb="imageURL"
/>
<van-coupon-cell
  :coupons="coupons"
  :chosen-coupon="chosenCoupon"
  @click="showList = true"
/>

  <van-cell title="配送方式" value="快递" is-link></van-cell>

  <van-field
    v-model="remark"
    label="买家留言"
    type="textarea"
    placeholder="点击给商家留言"
    rows="1"
    autosize
  />
  <van-cell title="合计" value="¥ 3800" value-class="color-red"></van-cell>
</van-cell-group>
    </div>
    <van-submit-bar
      :price="3050"
      button-text="提交订单"
      @submit="onSubmit"
    />

    <!-- 优惠券弹层 -->
  <van-popup v-model="showList" position="bottom">
    <van-coupon-list
      :coupons="coupons"
      :chosen-coupon="chosenCoupon"
      :disabled-coupons="disabledCoupons"
      @change="onChange"
      @exchange="onExchange"
    />
  </van-popup>
  </div>
</template>

<script>

import { Card,Field ,CouponCell, CouponList,SubmitBar } from 'vant'
import { storage } from '@/common/util'
import { mapState,mapMutations} from 'vuex'
const coupon = {
  available: 1,
  condition: '无使用门槛\n最多优惠12元',
  reason: '',
  value: 150,
  name: '优惠券名称',
  startAt: 1489104000,
  endAt: 1514592000,
  valueDesc: '1.5',
  unitDesc: '元'
}
export default {
  components: {
    [Card.name]: Card,
    [Field.name]: Field,
    [CouponCell.name]: CouponCell,
    [CouponList.name]: CouponList,
    [SubmitBar.name]: SubmitBar,
  },
  data() {
    return {
      imageURL:'//img.yzcdn.cn/upload_files/2017/07/02/af5b9f44deaeb68000d7e4a711160c53.jpg',
      remark:'',
      chosenCoupon: -1,
      coupons: [coupon],
      disabledCoupons: [coupon],
      showList:false,
      // defaultAddress:{}
    }
  },
  computed:{
    ...mapState(['defaultAddress'])
  },
  created() { 
    // this.$bus.$on('defaultAddress',address=>{
    //   console.log(address)
    //   console.log(this)
      
    //      this.$nextTick(()=>{
    //                 this.address=1
    //             })
    // })
    // if(!this.defaultAddress.name){
    //   this.getDefaultAddress()
    // }else{
    //   this.defaultAddress = this.$store.state.defaultAddress
    // }
    
  },
  methods: {
    ...mapMutations(['updateDefaultAddress']),
    onAddressChoose(){
      this.$router.push({path:'/address-list'})
    },
    onChange(index) {
      this.showList = false;
      this.chosenCoupon = index;
    },
    onExchange(code) {
      this.coupons.push(coupon);
    },
    onSubmit(){
      this.$toast('提交订单')
    },
    getDefaultAddress(){
      this.$request.get('/user/shipping-address/default/',{token:storage.get('token')}).then(res=>{
        console.log(1)
        this.updateDefaultAddress(res.data)
      })
    }
  }
}
</script>

<style lang="less" scoped>
  .color-red{
    color:#f44!important;
  }
  .address-box{
    position: relative;
    box-sizing: border-box;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    padding:10px 15px;
    background: #fff;
    &-hd{
      flex: 1;
      // padding:0 10px;
      padding-left: 20px;
    }
    &-bd{
      
      
    }
    &-inner{
      position: relative;
      display: flex;
      justify-content: space-between;
      align-items: center;
      &-icon{
        position: absolute;
        top:2px;
        left: -20px;
      }
      &-title{
        font-size: 16px;
        color: #333;
        font-weight: bold;
        margin-bottom: 5px;
      }
      &-bottom{
        font-size: 12px;
        color: #666; 
      }
    }
    &:before{
      position: absolute;
      right: 0;
      bottom: 0;
      left: 0;
      height: 2px;
      background: -webkit-repeating-linear-gradient(135deg, #ff6c6c 0, #ff6c6c 20%, transparent 0, transparent 25%, #1989fa 0, #1989fa 45%, transparent 0, transparent 50%);
      background: repeating-linear-gradient(-45deg, #ff6c6c 0, #ff6c6c 20%, transparent 0, transparent 25%, #1989fa 0, #1989fa 45%, transparent 0, transparent 50%);
      background-size: 80px;
      content: '';
    }
  }
  .address-card{
    position: relative;
    padding: 10px 15px;
    align-items: center;
    &:before{
      position: absolute;
      right: 0;
      bottom: 0;
      left: 0;
      height: 2px;
      background: -webkit-repeating-linear-gradient(135deg, #ff6c6c 0, #ff6c6c 20%, transparent 0, transparent 25%, #1989fa 0, #1989fa 45%, transparent 0, transparent 50%);
      background: repeating-linear-gradient(-45deg, #ff6c6c 0, #ff6c6c 20%, transparent 0, transparent 25%, #1989fa 0, #1989fa 45%, transparent 0, transparent 50%);
      background-size: 80px;
      content: '';
    }
  }
  .address-card .van-cell__left-icon{
    color: #1989fa; 
    font-size: 40px;
  }
  .address-card .van-cell__title{
    line-height: 40px;
  }
  .order-info{
    box-sizing: border-box;
    width:100%;
    // padding:0 15px;
    background: #fff;
  }
</style>


