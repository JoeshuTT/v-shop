<template>
    <div class="container pd50">
      <div class="user-header">
        <div class="user-hd">
          <img class="user-avatar" src="" alt="">
        </div>
        <div class="user-bd">
          <div class="user-bd-title">Joeshu</div>
          <div class="user-bd-txt">你还没有个性签名哦...</div>
        </div>
        <div class="user-ft">
          <div class="user-ft-right"><van-icon name="arrow" /></div>
        </div>
      </div>
      <div class="user-main">
        <div class="user-section">
          <div class="user-section-hd van-hairline--bottom"><div class="user-section-title">全部订单</div> <van-icon class="ml10" name="arrow" /></div>
          <div class="user-section-bd ui-clearfix">
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代付款</div></div>
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代发货</div></div>
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代收货</div></div>
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代评价</div></div>
          </div>
        </div>
        <div class="user-section">
          <div class="user-section-hd van-hairline--bottom"><div class="user-section-title">常用</div> </div>
          <div class="user-section-bd ui-clearfix">
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代付款</div></div>
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代发货</div></div>
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代收货</div></div>
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代评价</div></div>
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代评价</div></div>
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代评价</div></div>
            <div class="user-section-grid"><img class="user-section-grid-img" src="" alt=""/><div class="user-section-grid-title">代评价</div></div>
          </div>
        </div>
        <div class="user-row">
          <van-cell title="关于" is-link />
          <van-cell title="日志" is-link />
        </div>
      </div>
      <!-- 底部导航栏 -->
      <van-tabbar route v-model="active">
  <van-tabbar-item
    replace
    to="/home"
    icon="home-o"
  >
    首页
  </van-tabbar-item>
  <van-tabbar-item
    replace
    to="/cart"
    icon="cart-o"
  >
    购物车
  </van-tabbar-item>
  <van-tabbar-item
    replace
    to="/user"
    icon="manager-o"
  >
    我的
  </van-tabbar-item>
</van-tabbar>
    </div>
</template>
<script>
import { Tabbar, TabbarItem,} from "vant";
export default {
  components: {
    [Tabbar.name]: Tabbar,
    [TabbarItem.name]: TabbarItem,
  },
  data() {
    return {
      active: 0,
      iamges: []
    };
  },
  mounted() {

  },
  methods: {

  }
};
</script>
<style lang="less" scopde>
  .ml10{
    margin-left:10px;
  }
  .user-header{
    box-sizing: border-box;
    width: 100%;
    padding: 0 15px;
    background: #1989fa;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    height:180px;
    color: #fff;
  }
  .user-hd{
    margin-right: 10px;
  }
  .user-bd{
    
    &-title{
      font-size: 20px;
    }
    &-txt{
      font-size: 14px;
    }
  }
  .user-hd{
    margin-right: 10px;
  }
  .user-avatar{
    width:60px;
    height:60px;
    border-radius:50%;
    background: #eee;
    overflow: hidden;
  }
  .user-bd{
    flex: 1;
  }
  .user-main{
    // padding:0 20px;
    margin-top: -40px;
  }
  .user-section{
    box-sizing: border-box;
    border-radius:8px;
    overflow: hidden;
    background:#fff;
    margin:0 20px 15px 20px;
    padding:0 15px;
    min-height:100px;
    &-title{
      font-size: 14px;
      color: #000;
      font-weight: bold;
    }
    &-hd{
      box-sizing: border-box;
      width: 100%;
      padding: 10px 0px;
      overflow: hidden;
      color: #323233;
      font-size: 14px;
      line-height: 24px;
      background-color: #fff;
      display: flex;
      align-items: center;
    }
    &-bd{
      box-sizing: border-box;
      margin-left: -20px;
      margin-right: -20px;
      // width:100%;
      padding: 20px 10px;
    }
    &-grid{
      box-sizing: border-box;
      width:25%;
      float: left;
      text-align: center;
      &-img{
        display: inline-block;
        width:30px;
        height:30px;
        margin-bottom: 5px;
      }
      &-title{
        color: #333;
        font-size: 12px;
      }
    }
  }
  // 
  .user-row{
    box-sizing: border-box;
    border-radius:8px;
    overflow: hidden;
    background:#fff;
    margin:15px 20px;
  }
</style>



