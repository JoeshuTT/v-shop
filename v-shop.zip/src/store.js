import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store ({
    state: {
        count: 0,
        defaultAddress:{}
    },
    mutations: {
        increment (state) {
            state.count++
        },
        updateDefaultAddress(state,address){
            state.defaultAddress = address
        }
    }
})
export default store