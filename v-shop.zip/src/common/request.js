import Axios from 'axios'
import Qs from 'qs' 
import router from '@/router'
// import { Dialog } from 'vant';
// const API_BASE_URL = 'https://api.it120.cc'
// const API_BASE_URL = 'http://wx.lohike.net'
// 默认请求地址
Axios.defaults.baseURL = process.env.VUE_APP_BASE_API // url = base url + request url
Axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8'
// console.log(Qs)
// 请求(http request)拦截器 提前处理

// 响应(http response)拦截器 处理异常
Axios.interceptors.response.use(res => {
    if(res.data.code === 2000){
        // console.log(res.data.msg)
        // Dialog.alert({
        //     title: '提示',
        //     message: res.data.msg
        //   }).then(() => {
        //     // on close
        //     router.replace({path:'/login'})
        //   });
        setTimeout(() => {
            router.replace({path:'/login'})
        }, 2000);
    }
    return res
})
class request {
    // static get(url,params){
    //     return Axios.get(url,{params})
    // }
    static get(url,params){
        return new Promise((resolve,reject)=>{
            Axios.get(url,{params})
                .then(res=>{
                    if(res.status === 200){
                        resolve(res.data)
                    }else{
                        alert(res.data.msg)
                        reject(res.data)
                    }
                })
                .catch(err=>{
                    alert('哎呦，网络开小差了≧﹏≦!')
                    reject(err)
                })
        })
    }
    static post(url,params){
        return new Promise((resolve,reject)=>{
            Axios.post(url,Qs.stringify(params))
                .then(res=>{
                    if(res.status === 200){
                        resolve(res.data)
                    }else{
                        alert(res.data.msg)
                        reject(res.data)
                    }
                })
                .catch(err=>{
                    alert('哎呦，网络开小差了≧﹏≦!')
                    reject(err)
                })
        })
    }
}
export default request