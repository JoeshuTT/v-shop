/**
 * @param {string} str
 * @returns {Boolean}
 */
export function isString(str) {
    if (typeof str === 'string' || str instanceof String) {
      return true
    }
    return false
}
  
/**
 * @param {Array} arg
 * @returns {Boolean}
 */
export function isArray(arg) {
    if (typeof Array.isArray === 'undefined') {
      return Object.prototype.toString.call(arg) === '[object Array]'
    }
    return Array.isArray(arg)
}
/**
 * @param {String} value 
 */
export function isPhone(value){
    const reg = /^1[0-9]{10}$/
    return reg.test(value)
}

export function isEmpty(value){
    return `${value}`.trim().length
}
export function isEmail(value){
    const reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return reg.test(value)
}

export function isNumber(value){
    return /^\d+$/.test(value)
}