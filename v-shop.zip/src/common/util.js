// function localStorage() {
//     if(!window.localStorage){
//         alert('浏览器不支持localstorage')
//         return false
//     }
// 	return window.localStorage
// }

const storage = {
    set(key, data){
        window.localStorage.setItem(key,JSON.stringify(data))
    },
    get(key){
        return JSON.parse(window.localStorage.getItem(key))
    },
    remove(key){
        window.localStorage.removeItem(key)
    },
    clearAll(){
        window.localStorage.clear()
    }
}
const sessionStorage = {
    set(key, data){
        window.sessionStorage.setItem(key,JSON.stringify(data))
    },
    get(key){
        return JSON.parse(window.sessionStorage.getItem(key))
    },
    remove(key){
        window.sessionStorage.removeItem(key)
    },
    clearAll(){
        window.sessionStorage.clear()
    }
}
export {
    storage,
    sessionStorage
} 